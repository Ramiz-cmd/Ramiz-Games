RAMIZ GAMES

Сайт состоит из index.html. Чтобы опубликовать через GitHub Pages:
1. Открой свой репозиторий Ramiz-Games.
2. Нажми Add file -> Upload files.
3. Загрузи index.html в корень репозитория (не внутрь папки).
4. Нажми Commit changes.
5. В Settings -> Pages проверь, что публикация идёт из ветки main и папки /(root).
6. Открой https://ramiz-cmd.github.io/Ramiz-Games/ и обнови страницу.

Шахматы используют chess.js с CDN, поэтому для этой игры нужен интернет.
